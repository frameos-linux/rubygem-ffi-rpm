#ifndef _PLATFORM_H
#define	_PLATFORM_H

#ifdef	__cplusplus
extern "C" {
#endif

    extern void rbffi_Platform_Init(VALUE moduleFFI);


#ifdef	__cplusplus
}
#endif

#endif	/* _PLATFORM_H */

