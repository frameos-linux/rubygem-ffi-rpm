
#ifndef _AUTOPOINTER_H
#define	_AUTOPOINTER_H

#ifdef	__cplusplus
extern "C" {
#endif

extern void rbffi_AutoPointer_Init(VALUE ffiModule);
extern VALUE rbffi_AutoPointerClass;


#ifdef	__cplusplus
}
#endif

#endif	/* _AUTOPOINTER_H */

